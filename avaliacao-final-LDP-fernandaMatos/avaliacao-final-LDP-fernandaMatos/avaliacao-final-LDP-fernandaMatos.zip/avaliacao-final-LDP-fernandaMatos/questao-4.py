# Questão 4

cursos_superiores = ['Medicina', 'Direito', 'Engenharia']
print(f"Lista de cursos superiores mais desejados pelos candidatos: \n{cursos_superiores}")

cursos_superiores.append('Engenharia de Software')
print(f"Lista ATUALIZADA de cursos superiores mais desejados pelos candidatos: \n{cursos_superiores}")
