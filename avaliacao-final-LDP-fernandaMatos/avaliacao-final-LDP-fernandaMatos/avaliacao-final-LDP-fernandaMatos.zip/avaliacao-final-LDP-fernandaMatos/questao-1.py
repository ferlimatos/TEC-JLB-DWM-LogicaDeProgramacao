# Questão 1

# Entrada de Dados do Candidato
nome_completo = input("Informe seu nome completo: ")
cadastro_único = int(input("Digite seu número de CPF (sem ponto ou traço): "))
email = input("Informe seu endereço de e-mail: ")
senha = int(input("Digite sua senha: "))

# Saída de Dados do Candidato
print(f"Cadastro para o ENEM 2025 concluído com sucesso. Seus dados de inscrição são: \nNome completo: {nome_completo}\nCPF: {cadastro_único}\nE-mail: {email}\nSenha: {senha}")
