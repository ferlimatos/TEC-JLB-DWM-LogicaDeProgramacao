# Questão 7

media_enem = int(input("Qual foi a sua média no ENEM 2025: "))
curso_mensalidade = 1000

if media_enem  <= 450:
    desconto = 20/100
    mensalidade_total = 1000 - (curso_mensalidade * desconto)
    print(f"Sua media no ENEM 2025 é {media_enem}. O desconto aplicado será de {desconto:.2%}. O valor total da mensalidade será R${mensalidade_total}.")

elif 451 <= media_enem <= 550:
    desconto = 30/100
    mensalidade_total = 1000 - (curso_mensalidade * desconto)
    print(f"Sua media no ENEM 2025 é {media_enem}. O desconto aplicado será de {desconto:.2%}. O valor total da mensalidade será R${mensalidade_total}.")
    
elif 551 <= media_enem <= 600:
    desconto = 35/100
    mensalidade_total = 1000 - (curso_mensalidade * desconto)
    print(f"Sua media no ENEM 2025 é {media_enem}. O desconto aplicado será de {desconto:.2%}. O valor total da mensalidade será R${mensalidade_total}.")

elif 601 <= media_enem <= 650:
    desconto = 40/100
    mensalidade_total = 1000 - (curso_mensalidade * desconto)
    print(f"Sua media no ENEM 2025 é {media_enem}. O desconto aplicado será de {desconto:.2%}. O valor total da mensalidade será R${mensalidade_total}.")

elif 651 <= media_enem <= 700:
    desconto = 50/100
    mensalidade_total = 1000 - (curso_mensalidade * desconto)
    print(f"Sua media no ENEM 2025 é {media_enem}. O desconto aplicado será de {desconto:.2%}. O valor total da mensalidade será R${mensalidade_total}.")
        
else:
    print(f"Sua media no ENEM 2025 é {media_enem}. O desconto aplicado será de 100%. Portanto, você não precisará pagar mensalidade.")